# RiffLab — Technical & Product Specification
Version: 0.1 | Status: initial implementation baseline

## Product goal
A personal, adaptive guitar tutor that takes one learner from chord/song-based beginner playing towards independently reproducing songs, moving between rhythm and lead parts, playing by ear, improvising and composing.

## User setup
- Instrument: acoustic guitar (steel-string assumed only for initial audio tests; confirm if nylon-string).
- Audio input: Android phone microphone.
- Primary device: Android phone.
- Typical practice availability: 30–60 minutes, with a useful 10-minute fallback.

## Non-goals
- Multi-user product, social features, public profiles, leaderboards.
- Ads, subscriptions, in-app purchases.
- Full DAW / production suite in the initial product.
- Always-on microphone or background recording.
- Pretending microphone analysis can assess every technique reliably.

## Core experience
1. Home shows one obvious next action and today's song.
2. Daily session combines a personally selected/favourite song with one targeted musicianship skill.
3. User can choose 10, 30 or 60 minutes.
4. Skill tree shows the long-term destination and prerequisites.
5. Song library tracks actual repertoire and sections.
6. Progress is based on observable evidence and independent performance.
7. App works offline; cloud backup is optional.

## Learning model
### Shared foundations
- Rhythm, timing, chord transitions, fretting and picking.
- Fretboard notes, octaves, intervals and scale patterns.
- Ear training and musical vocabulary.

### Branches
- Ear: interval recognition, melody memory, transcription.
- Technique: picking control, legato, slides, bends and vibrato.
- Theory/fretboard: note locations, scales, harmony and chord functions.
- Rhythm-to-lead: accompaniment, fills, hooks, lead melodies, solos and transitions.
- Creation: riffs, improvisation, melody over progressions and composition.

### Mastery
A skill is not unlocked by watching content. Each node has:
- learning objective;
- guided practice;
- measurable check;
- independent/mastery trial;
- confidence/evidence state;
- spaced review schedule.

No fake precision: if the audio engine cannot measure a skill reliably, use a human self-check or mark it unassessed.

## Song model
Each song may contain sections: intro, verse, chorus, bridge, instrumental, solo, outro.
Each section may have guitar roles: rhythm, arpeggio, fill, hook, lead melody, solo.
Difficulty arrangements: simplified, authentic, advanced.
Song progress: discovered, learning, slow-clean, original-tempo, independent, by-ear.
Daily queue should include at least one user-liked song. Listening-history suggestions are optional and always user-approved.

## Practice session templates
- 10 min: short warm-up + one song phrase or one targeted skill.
- 30 min: technique/foundation + target skill + favourite song + short ear/creation task.
- 60 min: longer skill block + song section work + ear/creation + unaided recall.
Allocation adapts to current goal and user feedback. No punitive streaks.

## Audio constraints
Initial acoustic guitar support:
- microphone permission only when a relevant exercise starts;
- input-level/noise check;
- tuner and single-note pitch detection first;
- monophonic note and timing exercises before polyphonic chord assessment;
- no claim of accurate bend/vibrato/tone assessment until tested on real acoustic recordings;
- all processing should be on-device in the initial version where practical;
- no recording retention by default.

## Data and ownership
Local database is source of truth initially. Export all user data to JSON/CSV. Include schema version, app version and timestamps. No credentials or secrets in diagnostic exports. Optional cloud backup only after local persistence works. Any diagnostic sharing is explicit and scoped.

## Technical stack
- Android native: Kotlin + Jetpack Compose.
- Persistence milestone: Room (SQLite).
- Audio milestone: Android AudioRecord with tested pitch detection implementation.
- Architecture: UI / domain learning engine / data repository separated.
- Backend: deferred. Keep repository interfaces cloud-ready; choose Supabase/Postgres only if remote backup or direct authorised diagnostic access becomes necessary.
- Source control: private Git repository owned by the user. Do not place secrets in source control.

## Milestones / acceptance
### M0 — scaffold (current)
App shell, navigation, practice entry points, skill-tree outline, manual song entry, microphone permission request.

### M1 — reliable personal data
Room persistence; songs, sessions, settings, skill evidence; import/export; app survives restart without losing data.

### M2 — audio fundamentals
Permission flow, input meter, tuner, single-note detection validated against reference pitches and noisy-room conditions.

### M3 — real learning loop
Adaptive session plan, practice timer, targeted drills, song section checklist, evidence-based progress and review scheduling.

### M4 — song arrangement learning
Section/role map, simplified/authentic/advanced arrangements, loop/tempo support and rhythm-to-lead transitions.

### M5 — diagnostics and optional cloud
Sanitised diagnostic bundle, schema documentation, optional private sync and authorised read-only access.

## Quality gates
- No feature is called complete without a working test path.
- No progress metric without a defined measurement.
- No cloud requirement for core practice.
- No audio data stored or transmitted without explicit consent.
- Changes preserve existing user data and include migration tests.
