package com.rifflab.personal

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

private val Ink = Color(0xFF171923)
private val Muted = Color(0xFF777D8B)
private val Accent = Color(0xFF9B7BFF)
private val SurfaceDark = Color(0xFF222633)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RiffLabApp() }
    }
}

private enum class Tab { HOME, TREE, SONGS, PROGRESS }

@Composable
private fun RiffLabApp() {
    var tab by remember { mutableStateOf(Tab.HOME) }
    var activeSession by remember { mutableStateOf(false) }
    var sessionLength by remember { mutableIntStateOf(30) }
    var completedMinutes by remember { mutableIntStateOf(0) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            background = Ink,
            surface = SurfaceDark,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = SurfaceDark) {
                    val items = listOf(
                        Triple(Tab.HOME, "Today", Icons.Default.Home),
                        Triple(Tab.TREE, "Skill tree", Icons.Default.AccountTree),
                        Triple(Tab.SONGS, "Songs", Icons.Default.LibraryMusic),
                        Triple(Tab.PROGRESS, "Progress", Icons.Default.Insights)
                    )
                    items.forEach { (item, label, icon) ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when {
                    activeSession -> SessionScreen(
                        length = sessionLength,
                        onFinish = {
                            completedMinutes += sessionLength
                            activeSession = false
                        },
                        onExit = { activeSession = false }
                    )
                    tab == Tab.HOME -> HomeScreen(
                        onStart = { minutes -> sessionLength = minutes; activeSession = true },
                        onSong = { tab = Tab.SONGS }
                    )
                    tab == Tab.TREE -> SkillTreeScreen()
                    tab == Tab.SONGS -> SongsScreen()
                    else -> ProgressScreen(completedMinutes)
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(onStart: (Int) -> Unit, onSong: () -> Unit) {
    val context = LocalContext.current
    var micGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        micGranted = it
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text("RIFFLAB", color = Accent, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Text("Your guitar journey.", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("One focused session at a time.", color = Muted)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("TODAY'S PRACTICE", color = Accent, style = MaterialTheme.typography.labelMedium)
                    Text("Build a little more musical independence.", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    Text("A song you love + one skill that helps you play it.", color = Muted)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SessionChip("10 min", Modifier.weight(1f)) { onStart(10) }
                        SessionChip("30 min", Modifier.weight(1f)) { onStart(30) }
                        SessionChip("60 min", Modifier.weight(1f)) { onStart(60) }
                    }
                }
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth().clickable(onClick = onSong),
                colors = CardDefaults.cardColors(containerColor = SurfaceDark)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MusicNote, contentDescription = null, tint = Accent, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Your song of the day", fontWeight = FontWeight.SemiBold)
                        Text("Choose a favourite to keep in circulation.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = "Open songs")
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MICROPHONE SETUP", fontWeight = FontWeight.SemiBold)
                    Text(
                        if (micGranted) "Microphone permission granted. Pitch and timing assessment will be added in the audio milestone."
                        else "RiffLab will use your phone microphone for acoustic-guitar feedback.",
                        color = Muted,
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (!micGranted) {
                        OutlinedButton(onClick = { micPermission.launch(Manifest.permission.RECORD_AUDIO) }) {
                            Icon(Icons.Default.Mic, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Enable microphone")
                        }
                    } else {
                        Text("Permission enabled", color = Color(0xFF70D6A0), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
        item {
            Text("DESIGN PROMISE", color = Accent, style = MaterialTheme.typography.labelMedium)
            Text("No feeds. No guilt streaks. Progress is earned by what you can actually play.", color = Muted)
        }
    }
}

@Composable
private fun SessionChip(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = modifier, contentPadding = PaddingValues(vertical = 12.dp)) {
        Text(label)
    }
}

@Composable
private fun SessionScreen(length: Int, onFinish: () -> Unit, onExit: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("PRACTICE SESSION", color = Accent, style = MaterialTheme.typography.labelLarge)
        Spacer(Modifier.height(12.dp))
        Text("$length minutes", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
        Text("Your session is ready. Work on your song, then connect the skill to it.", color = Muted)
        Spacer(Modifier.height(28.dp))
        Button(onClick = onFinish, modifier = Modifier.fillMaxWidth()) { Text("Mark session complete") }
        TextButton(onClick = onExit) { Text("Exit session") }
        Text("MVP note: session timing and detailed exercise guidance are next implementation steps.", color = Muted, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun SkillTreeScreen() {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("SKILL TREE", color = Accent, style = MaterialTheme.typography.labelLarge)
            Text("Become the guitarist you imagine.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("A visible map. Unlock skills by demonstrating them, not watching lessons.", color = Muted)
        }
        item { SkillNode("Foundations", "Chord changes · Rhythm · Picking · Fretting", "Start here", true) }
        item { SkillNode("The ear", "Intervals · Melody recognition · Transcription", "Build listening skills", false) }
        item { SkillNode("Technique", "Picking · Slides · Hammer-ons · Bends · Vibrato", "Develop control", false) }
        item { SkillNode("Fretboard & theory", "Notes · Octaves · Scales · Harmony", "Understand the neck", false) }
        item { SkillNode("Rhythm-to-lead", "Fills · Hooks · Lead melodies · Song transitions", "Play complete arrangements", false) }
        item { SkillNode("Creation", "Riffs · Improvisation · Melodies · Composition", "Make your own music", false) }
        item { SkillNode("Musical independence", "Play by ear · Arrange · Perform · Compose", "Long-term destination", false) }
    }
}

@Composable
private fun SkillNode(title: String, detail: String, status: String, unlocked: Boolean) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                if (unlocked) Icons.Default.RadioButtonChecked else Icons.Default.Lock,
                contentDescription = null,
                tint = if (unlocked) Accent else Muted,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(detail, color = Muted, style = MaterialTheme.typography.bodySmall)
                Text(status, color = if (unlocked) Color(0xFF70D6A0) else Muted, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun SongsScreen() {
    var songTitle by remember { mutableStateOf("") }
    var songArtist by remember { mutableStateOf("") }
    var songs by remember { mutableStateOf(listOf<Pair<String, String>>()) }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("SONG LIBRARY", color = Accent, style = MaterialTheme.typography.labelLarge)
        Text("Learn music you actually love.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Add songs manually for now. Service connections and audio import are planned after the core learning loop.", color = Muted)
        OutlinedTextField(value = songTitle, onValueChange = { songTitle = it }, label = { Text("Song title") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = songArtist, onValueChange = { songArtist = it }, label = { Text("Artist (optional)") }, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = {
                if (songTitle.isNotBlank()) {
                    songs = songs + (songTitle.trim() to songArtist.trim())
                    songTitle = ""; songArtist = ""
                }
            },
            enabled = songTitle.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Add to my songs") }
        if (songs.isEmpty()) {
            Text("Your repertoire is empty. Add a song you want to learn.", color = Muted)
        } else {
            Text("YOUR REPERTOIRE", color = Accent, style = MaterialTheme.typography.labelMedium)
            songs.forEach { (title, artist) ->
                Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = Accent)
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(title, fontWeight = FontWeight.SemiBold)
                            if (artist.isNotBlank()) Text(artist, color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProgressScreen(completedMinutes: Int) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("YOUR PROGRESS", color = Accent, style = MaterialTheme.typography.labelLarge)
        Text("Evidence over empty streaks.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
            Column(Modifier.padding(18.dp)) {
                Text("Practice minutes recorded in this app session", color = Muted)
                Text("$completedMinutes min", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Bold)
            }
        }
        Text("Next: persistent practice history, measurable skill assessments, mastery trials and exportable diagnostics.", color = Muted)
    }
}
