# RiffLab — personal guitar tutor (MVP scaffold)

RiffLab is a single-person Android guitar-learning app for an acoustic guitar, using the phone microphone as the intended audio input.

## Current prototype (0.1.0)
- Compose Android app shell with Today, Skill Tree, Songs and Progress sections.
- 10 / 30 / 60 minute session entry points.
- Manual song repertoire entry (prototype state is currently in-memory).
- Microphone permission request.
- Initial skill-tree structure, including rhythm-to-lead and creation.

**This is source code, not an installable APK.** The current prototype does not yet implement audio pitch detection, durable database storage, cloud sync, Spotify/YouTube Music connections, or real song transcription. The progress display is intentionally labelled as a prototype so it does not imply fake mastery data.

## Build
1. Install Android Studio (recent stable version) and Android SDK Platform 35.
2. Open this folder as an existing Gradle project.
3. Allow Gradle to sync and download dependencies.
4. Select an Android device or emulator and run the `app` configuration.

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21 and Jetpack Compose.

## Product principles
- Personal, single-user app; no social feed, ads, subscriptions or leaderboard.
- Local-first and usable offline.
- Favourite-song practice every day, alongside musicianship development.
- Skill unlocks based on demonstrated ability, not lesson consumption.
- No punitive streaks or inflated XP.
- Diagnostics and export are user-controlled.

## Planned implementation milestones
1. **Persistence:** Room database for songs, sessions, skill evidence, settings and diagnostic events.
2. **Acoustic audio engine:** microphone capture, input-level checks, monophonic pitch detection, tuner and note/timing exercises. Do not claim reliable chord/bend assessment until validated.
3. **Practice engine:** 10/30/60-minute session plans, adaptive drills, revision scheduling and mastery trials.
4. **Song learning:** sections, arrangement roles (rhythm, fills, lead, solo), simplified/authentic/advanced arrangements, tempo and looping.
5. **Personal diagnostics:** JSON/CSV export, app/build version, event logs and data dictionary.
6. **Optional private cloud:** encrypted transport, user-controlled backup/sync and read-only diagnostic sharing. Cloud is not required for core use.
7. **Music-service integrations:** investigate supported official APIs and permission boundaries before implementing. Manual links/import remain the fallback.

## Architecture decision
Start local-first. Keep the learning engine and curriculum independent of any cloud vendor. Add optional backend sync only after the offline learning loop and data model are stable. This avoids making a personal app dependent on a server bill or third-party API.
