# Build an installable RiffLab APK using GitHub Actions

This project currently contains Android source code, not an APK.

## Build from a browser (no Android Studio required)

1. Create a **private** GitHub repository while signed in to your GitHub account.
2. Upload the contents of this project folder to the repository's `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build RiffLab APK** and choose **Run workflow** (or wait for the first push build).
5. When the workflow completes successfully, open that run and download the `RiffLab-debug-apk` artifact.
6. Extract the artifact ZIP. It contains `app-debug.apk`. Transfer it to your Android phone and install it. Android may ask you to allow installation from that source.

The workflow builds a **debug APK**. It is suitable for personal testing, not Play Store distribution.

## Important

- The workflow is included but has not been run yet.
- A successful GitHub Actions run is required before an APK exists.
- The current app is still an early UI prototype. Song/session data is not yet durable across app restarts, and microphone-based tuner/pitch analysis is not implemented.
